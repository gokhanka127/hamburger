# Modern Burger Sass Responsive Project

## What I Practice

 - Designed using only html and css with scss
 - Responsive
 
### `Deploy` 

 <img src="https://www.svgrepo.com/show/376339/netlify.svg" ald="Cloud Image" widt='20' height='20' /> https://burger-sass.netlify.app/

### `Screen`  </br>

![](screen.gif)  
